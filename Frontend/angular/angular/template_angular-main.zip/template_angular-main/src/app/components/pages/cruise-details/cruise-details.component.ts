import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cruise-details',
  templateUrl: './cruise-details.component.html',
  styleUrls: ['./cruise-details.component.css']
})
export class CruiseDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
