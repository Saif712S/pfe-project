import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotels-grid',
  templateUrl: './hotels-grid.component.html',
  styleUrls: ['./hotels-grid.component.css']
})
export class HotelsGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
