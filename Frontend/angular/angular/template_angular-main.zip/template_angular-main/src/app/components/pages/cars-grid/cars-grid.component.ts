import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars-grid',
  templateUrl: './cars-grid.component.html',
  styleUrls: ['./cars-grid.component.css']
})
export class CarsGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
