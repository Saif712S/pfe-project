import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotels-grid-right',
  templateUrl: './hotels-grid-right.component.html',
  styleUrls: ['./hotels-grid-right.component.css']
})
export class HotelsGridRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
