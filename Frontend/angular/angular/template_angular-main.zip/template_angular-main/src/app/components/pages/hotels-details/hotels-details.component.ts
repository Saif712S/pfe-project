import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotels-details',
  templateUrl: './hotels-details.component.html',
  styleUrls: ['./hotels-details.component.css']
})
export class HotelsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
