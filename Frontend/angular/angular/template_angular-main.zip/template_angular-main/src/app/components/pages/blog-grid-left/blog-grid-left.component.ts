import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-grid-left',
  templateUrl: './blog-grid-left.component.html',
  styleUrls: ['./blog-grid-left.component.css']
})
export class BlogGridLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
