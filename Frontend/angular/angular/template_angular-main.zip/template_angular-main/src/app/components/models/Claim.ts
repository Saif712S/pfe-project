export class Claim {
    id!: number;
    dateDiff!: Date;
    dateRes!: Date;
    title!: string;
    description!: string;
    cause!: string;
    status!: string;
    typeClaim!: string;
  }