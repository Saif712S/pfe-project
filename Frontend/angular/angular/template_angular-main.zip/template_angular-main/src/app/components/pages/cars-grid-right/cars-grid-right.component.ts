import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars-grid-right',
  templateUrl: './cars-grid-right.component.html',
  styleUrls: ['./cars-grid-right.component.css']
})
export class CarsGridRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
