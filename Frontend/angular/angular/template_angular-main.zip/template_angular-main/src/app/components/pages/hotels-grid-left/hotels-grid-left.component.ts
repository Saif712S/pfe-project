import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotels-grid-left',
  templateUrl: './hotels-grid-left.component.html',
  styleUrls: ['./hotels-grid-left.component.css']
})
export class HotelsGridLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
