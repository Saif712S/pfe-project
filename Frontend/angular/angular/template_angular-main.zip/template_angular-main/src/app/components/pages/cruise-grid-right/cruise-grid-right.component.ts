import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cruise-grid-right',
  templateUrl: './cruise-grid-right.component.html',
  styleUrls: ['./cruise-grid-right.component.css']
})
export class CruiseGridRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
