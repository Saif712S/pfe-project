import { Component } from '@angular/core';
import { CruiseHelperService } from 'src/app/components/helper/cruise/cruise-helper.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent extends CruiseHelperService {

}
