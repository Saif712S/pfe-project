import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flights-grid',
  templateUrl: './flights-grid.component.html',
  styleUrls: ['./flights-grid.component.css']
})
export class FlightsGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
