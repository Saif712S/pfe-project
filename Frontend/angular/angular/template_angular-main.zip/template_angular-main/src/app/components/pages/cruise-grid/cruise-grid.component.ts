import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cruise-grid',
  templateUrl: './cruise-grid.component.html',
  styleUrls: ['./cruise-grid.component.css']
})
export class CruiseGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
