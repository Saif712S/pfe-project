import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cruise-grid-left',
  templateUrl: './cruise-grid-left.component.html',
  styleUrls: ['./cruise-grid-left.component.css']
})
export class CruiseGridLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
