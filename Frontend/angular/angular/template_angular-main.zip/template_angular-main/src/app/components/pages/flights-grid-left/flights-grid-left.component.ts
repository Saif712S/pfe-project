import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flights-grid-left',
  templateUrl: './flights-grid-left.component.html',
  styleUrls: ['./flights-grid-left.component.css']
})
export class FlightsGridLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
