import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-details-right',
  templateUrl: './blog-details-right.component.html',
  styleUrls: ['./blog-details-right.component.css']
})
export class BlogDetailsRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
