import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-details-left',
  templateUrl: './blog-details-left.component.html',
  styleUrls: ['./blog-details-left.component.css']
})
export class BlogDetailsLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
