import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-grid-right',
  templateUrl: './blog-grid-right.component.html',
  styleUrls: ['./blog-grid-right.component.css']
})
export class BlogGridRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
