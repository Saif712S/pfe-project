import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars-grid-left',
  templateUrl: './cars-grid-left.component.html',
  styleUrls: ['./cars-grid-left.component.css']
})
export class CarsGridLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
