import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flights-grid-right',
  templateUrl: './flights-grid-right.component.html',
  styleUrls: ['./flights-grid-right.component.css']
})
export class FlightsGridRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
