export interface Item {
    id: string;
    image: string;
    category: number[];
}