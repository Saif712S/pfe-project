import { Component } from '@angular/core';
import { CruiseHelperService } from '../../helper/cruise/cruise-helper.service';

@Component({
  selector: 'app-cruise-sidebar',
  templateUrl: './cruise-sidebar.component.html',
  styleUrls: ['./cruise-sidebar.component.css']
})
export class CruiseSidebarComponent extends CruiseHelperService {

}
