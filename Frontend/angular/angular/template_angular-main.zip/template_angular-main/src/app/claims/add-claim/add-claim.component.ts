import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-claim',
  templateUrl: './add-claim.component.html',
  styleUrls: ['./add-claim.component.css']
})
export class AddClaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
